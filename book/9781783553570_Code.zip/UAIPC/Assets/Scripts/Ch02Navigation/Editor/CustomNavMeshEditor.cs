﻿using UnityEngine;
using UnityEditor;
using System.Collections;

[CustomEditor(typeof(CustomNavMesh))]
public class CustomNavMeshEditor : Editor
{
    

}
