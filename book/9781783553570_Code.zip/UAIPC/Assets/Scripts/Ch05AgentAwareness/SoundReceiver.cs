﻿using UnityEngine;
using System.Collections;

public class SoundReceiver : MonoBehaviour
{
    public float soundThreshold;

    public virtual void Receive(float intensity, Vector3 position)
    {
        // TODO
        // code your own behaviour here
    }
}
