﻿using UnityEngine;
using System.Collections;

public class MoveDraughts : Move
{
    public int x;
    public int y;
    public bool success;
    public int removeX;
    public int removeY;
    public PieceDraughts piece;
}
