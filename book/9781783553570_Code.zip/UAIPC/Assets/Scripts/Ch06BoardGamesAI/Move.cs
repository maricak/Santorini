﻿using UnityEngine;
using System.Collections;

public abstract class Move
{
    
}
