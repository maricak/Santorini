﻿public class Condition
{
    public virtual bool Test()
    {
        return false;
    }
}
