﻿public class Transition
{
    public Condition condition;
    public State target;    
}
